# Team Allocation & Capacity Sheet: Project Auro SuperApp
> **Notice: Generated in Demo Mode**

## Team Roster & Skill Matrix
- **Team Size**: 5 Core Members
- **Identified Skills**: TypeScript, React, PostgreSQL, Docker, Security Auditing, Test Automation

| Name | Role | Primary Skills | Weekly Capacity (hrs) |
|---|---|---|---|
| Alice Morgan | Lead Architect | Node.js, Systems, Drizzle, DB | 40 |
| Bob Chen | Frontend Specialist | React, Vite, Tailwind CSS | 40 |
| Carlos Diaz | QA Engineer | Vitest, E2E, Test Planning | 35 |
| Diana Vance | DevOps Engineer | Docker, CI/CD, Linux Sandboxes | 35 |
| Evan Wright | Security Lead | STRIDE, RBAC, Auth Audits | 20 |

## Workstream & Role Assignments
- **Architecture & Backend**: Alice Morgan (Lead), Bob Chen
- **UI & Document Center**: Bob Chen (Lead)
- **Quality Assurance**: Carlos Diaz
- **Infrastructure & Deployments**: Diana Vance
- **Security & Compliance**: Evan Wright

## Capacity Ratios & On-Call Coverage
- Development Capacity: 75%
- Review & Bug Triage: 15%
- Maintenance / On-Call: 10%
