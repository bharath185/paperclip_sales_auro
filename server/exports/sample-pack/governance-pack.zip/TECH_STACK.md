# Technology Stack & Justification: Project Auro SuperApp
> **Notice: Generated in Demo Mode**

## Stack Summary Matrix
| Layer | Technology | Version | Purpose |
|---|---|---|---|
| Frontend | React + Vite + Tailwind | React 19 / Vite 6 | Responsive, token-gated UI |
| Backend | Node.js + Express + TypeScript | Node 24 / TS 5.7 | API and orchestration engine |
| Database | PostgreSQL + Drizzle ORM | Postgres 16 | Relational data with type-safe schema |
| AI Adapter | OpenCode Provider Layer | Latest | Multi-model agent execution |

## Frontend & Backend Rationale
- Selection based on project requirements: Modern full-stack TypeScript.
- Shared type packages ensure end-to-end type safety between client and server.

## Database & Storage Layer
- Relational schema managed with strict migration numbering and tenant isolation checks.
- Artifacts and document versions stored with immutable history hashes.

## Third-Party Dependencies & Licensing
- All core dependencies use permissive licenses (MIT / Apache-2.0 / BSD).
