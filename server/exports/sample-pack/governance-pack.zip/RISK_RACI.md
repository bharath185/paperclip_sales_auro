# Risk Register & RACI Matrix: Project Auro SuperApp
> **Notice: Generated in Demo Mode**

## Project Risk Register & Scoring
| Risk ID | Description | Prob (1-5) | Impact (1-5) | Score | Mitigation |
|---|---|---|---|---|---|
| RISK-01 | Primary model quota exhaustion | 4 | 4 | 16 | Automatic fallback to secondary OpenCode model |
| RISK-02 | Scope creep during document refinement | 3 | 3 | 9 | Strict acceptance criteria and CEO approval gate |
| RISK-03 | Cross-platform sandbox differences | 3 | 4 | 12 | Standardized WSL2 / container deployment guidelines |

## RACI Governance Matrix
| Deliverable / Action | CEO | CTO | PM | QA | DevOps | Security |
|---|---|---|---|---|---|---|
| Project Charter & Vision | **A** | C | C | I | I | I |
| PRD & Requirements | C | C | **A** | C | I | I |
| Architecture & ADRs | I | **A** | C | I | C | C |
| Test Strategy & QA Plan | I | C | C | **A** | I | I |
| CI/CD & Infra Spec | I | C | I | I | **A** | C |
| Threat Model & Security | C | C | I | I | C | **A** |
| Final Pack Sign-off | **A** | C | C | C | C | C |

*Legend: **A** = Accountable, **R** = Responsible, **C** = Consulted, **I** = Informed*

## Contingency & Escalation Procedures
- Critical blockers are escalated directly to the CEO within the task discussion thread.
- Conflicting architectural requirements between Security and CTO trigger an ADR review session.
