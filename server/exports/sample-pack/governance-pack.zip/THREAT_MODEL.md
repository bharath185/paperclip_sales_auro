# Threat Model & Security Requirements: Project Auro SuperApp
> **Notice: Generated in Demo Mode**

## STRIDE Threat Analysis
| Threat Category | Potential Vector | Impact | Mitigation Strategy |
|---|---|---|---|
| **Spoofing** | Forged agent identity in REST calls | High | HMAC / Bearer agent API tokens with company scoping |
| **Tampering** | Unsanctioned prompt or document edit | High | Immutable document version logs & audit trail |
| **Repudiation** | Denied mutation of project pack | Medium | Activity log records for every mutating operation |
| **Information Disclosure** | API keys leaked in server logs | Critical | Masked key displays (last 4 chars) & hashed storage |
| **Denial of Service** | Model rate limit exhaustion | High | Automatic OpenCode fallback & exponential backoff |
| **Elevation of Privilege** | Cross-tenant company access | Critical | Company-scoped query gates on every route |

## Security Controls & Mitigations
- AES-256-GCM encryption for stored provider secrets.
- Strict sandbox enforcement preventing unauthorized disk or network traversal.

## Compliance, Secrets & Audit Logging
- All security-relevant actions write to the audit log table.
- Secret keys are never returned in plain text in API responses.
