# Database Schema (ER) & OpenAPI Specification: Project Auro SuperApp
> **Notice: Generated in Demo Mode**

## Entity-Relationship (ER) Diagram (Mermaid)
```mermaid
erDiagram
  COMPANY ||--o{ PROJECT : owns
  PROJECT ||--o{ GOVERNANCE_PACK : contains
  GOVERNANCE_PACK ||--o{ GOVERNANCE_DOCUMENT : holds
  GOVERNANCE_DOCUMENT ||--o{ DOCUMENT_VERSION : tracks
  GOVERNANCE_DOCUMENT ||--o{ DOCUMENT_REVIEW : receives

  COMPANY {
    uuid id PK
    string name
    string status
  }
  PROJECT {
    uuid id PK
    uuid company_id FK
    string name
  }
  GOVERNANCE_PACK {
    uuid id PK
    uuid project_id FK
    string status
  }
  GOVERNANCE_DOCUMENT {
    uuid id PK
    uuid pack_id FK
    string kind
    string title
  }
```

## Data Dictionary & Tables
- **governance_packs**: Holds overall pack lifecycle (draft, in_review, approved).
- **governance_documents**: Individual documents with validation states.
- **document_versions**: Content snapshots and author change summaries.

## OpenAPI 3.0 REST Specification Draft
```yaml
openapi: 3.0.3
info:
  title: Project Auro SuperApp Governance API
  version: 1.0.0
paths:
  /api/companies/{companyId}/governance/pack:
    get:
      summary: Retrieve active project governance pack
      responses:
        '200':
          description: Governance pack details
```
