# CI/CD Pipeline & Infrastructure Specification: Project Auro SuperApp
> **Notice: Generated in Demo Mode**

## Infrastructure Topology & Environments
- **Stack**: Node.js, PostgreSQL, Docker
- **Staging Environment**: Isolated VPC with automated ephemeral preview deployments.
- **Production Environment**: High-availability container cluster with automated health checks.

## CI/CD Workflow & Build Gates
1. **Pre-flight**: Node version policy check (`check:node-version`), forbidden tokens check.
2. **Compile & Gate**: TypeScript typecheck (`pnpm -r typecheck`), token-gates check (`check:token-gates`).
3. **Automated Test Suite**: Full server, adapter, and UI test runs.
4. **Artifact Build & Packaging**: Docker image build with signed metadata.

## Container & Sandbox Specification
- Linux: Bubblewrap (`bwrap`) sandbox with strictly confined `filesystemScope: workspace` and `networkScope: isolated`.
- Windows / Host: Isolated containerized dev environments.
