# System Architecture & ADRs: Project Auro SuperApp
> **Notice: Generated in Demo Mode**

## Architecture Overview
The architecture is structured around modular control plane services, isolated execution sandboxes, and autonomous multi-agent orchestration.

## System Component Diagram (Mermaid)
```mermaid
flowchart TD
  Client[Web UI / Mobile] --> Gateway[API Gateway / Router]
  Gateway --> GovService[Governance Service]
  Gateway --> AgentOrch[Agent Orchestration Engine]
  AgentOrch --> ModelProvider[OpenCode Model Provider Layer]
  ModelProvider --> DeepSeek[DeepSeek V4 Pro]
  ModelProvider --> Kimi[Kimi K2.7 Code]
  AgentOrch --> DocEngine[Document Generation & Validator]
  DocEngine --> Store[(Persistent Store / Artifacts)]
```

## Data Flow & Integration Points
- **External Integrations**: Standard REST / Webhooks
- **Preferred Stack**: TypeScript / Node.js / React

## Architectural Decision Records (ADRs)
### ADR-001: Model Provider Layer with Automatic Failover
- **Context**: Relying on a single AI provider causes downtime during quota exhaustion.
- **Decision**: Implement OpenCode provider with transparent fallback to DeepSeek V4 Flash / Pro.
- **Consequences**: Zero agent downtime; seamless quota management.
